#include <stdio.h>

int main() {
    FILE *archivo;

    float nuevoSaldo;

    printf("Ingrese el nuevo saldo que desea guardar:\n");
    scanf("%f", &nuevoSaldo);

    // Abrir en modo escritura (sobrescribe todo)
    archivo = fopen("datos.txt", "w");

    if (archivo == NULL) {
        printf("Error al abrir el archivo\n");
        return 1;
    }

    fprintf(archivo, "Saldo actualizado:\n %.2f", nuevoSaldo);

    fclose(archivo);

    printf("Archivo actualizado correctamente\n");

    return 0;
}