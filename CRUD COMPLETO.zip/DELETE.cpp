#include <stdio.h>

int main() {
    FILE *archivo;

    // Abrir en modo escritura sin escribir nada = borrar contenido
    archivo = fopen("datos.txt", "w");

    if (archivo == NULL) {
        printf("Error al abrir el archivo\n");
        return 1;
    }

    fclose(archivo);

    printf("Contenido del archivo eliminado\n");

    return 0;
}