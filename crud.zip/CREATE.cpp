#include <stdio.h>
int opcion, deposito, retiro;
float SALDO = 5000.00;
int main() {
    FILE *archivo;

    // Abrir archivo en modo escritura ("w" crea o sobrescribe)
    archivo = fopen("datos.txt", "w");

    if (archivo == NULL) {
        printf("Error al abrir el archivo\n");
        return 1;
    }


    do {
        printf("\n========CAJERO AUTOMATICO========\n");
        printf("1. CONSULTAR SALDO\n");
        printf("2. DEPOSITAR\n");
        printf("3. RETIRAR\n");
        printf("4. SALIR\n");
        printf("ELIGE UNA OPERACION\n");
        scanf("%d", &opcion);
        //switch para elegir opcion
        switch (opcion) {
            case 1:
                printf("Su saldo es:%.2f" ,  SALDO);
                break;

            case 2:
                printf("Cuanto desea depositar\n");
                scanf("%d", &deposito);
                if (deposito % 100 == 0 && deposito <= 20000) {
                    SALDO = deposito + SALDO;
                    printf("Su nuevo saldo es\n %.2f" , SALDO);
                    // Escribir en el archivo
                    fprintf(archivo, "Su saldo despues del deposito es\n %.2f" , SALDO);
                }
                else
                    printf("CANTIDAD INVALIDA");

                break;

            case 3:
                printf("Cuanto desea retirar\n");
                scanf("%d", &retiro);
                if (retiro > SALDO)
                    printf("No puede retirar mas que su saldo");
                else if (retiro % 50 == 0 && retiro <= 5000) {
                    SALDO = SALDO - retiro;
                    printf("Su nuevo nuevo saldo es\n %.2f" , SALDO);
                    // Escribir en el archivo
                    fprintf(archivo, "\nSu saldo despues del retiro es\n %.2f" , SALDO);
                }
                else
                    printf("CANTIDAD INVALIDA");

                break;

            case 4:
                printf("TERMINANDO OPERACION\n");
                break;

        }


        // while para terminar el ciclo
    } while(opcion!=4);



    // Cerrar el archivo
    fclose(archivo);

    printf("Archivo escrito exitosamente\n");

    return 0;
}
