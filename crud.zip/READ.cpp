#include <stdio.h>

int main() {
    FILE *archivo;
    char linea[100];

    // Abrir archivo en modo lectura ("r")
    archivo = fopen("datos.txt", "r");

    if (archivo == NULL) {
        printf("Error: No se pudo abrir el archivo\n");
        return 1;
    }

    // Leer y mostrar línea por línea
    printf("Contenido del archivo:\n");
    while (fgets(linea, sizeof(linea), archivo) != NULL) {
        printf("%s", linea);
    }

    // Cerrar el archivo
    fclose(archivo);

    return 0;
}